import java.util.*;

/**
 * Klasa reprezentuj�ca hotel ze 100 pokojami
 * @author Piotr Palus
 * 18.11.2015
 */
public class Hotel
{
    Osoba[] tablica=new Osoba[101];


    /**
     * Metoda przypisuje osob� do wybranego pokoju, je�li jest prawid�owy
     * @param room
     *          Numer wybranego pokoju
     * @param imie
     *          Imie go�cia
     * @param nazwisko
     *          Nazwisko go�cia
     */
    public void giveRoom(int room, String imie, String nazwisko)
    {
        if(room>0&&room<101)
        {
            if(tablica[room]==null) tablica[room]=new Osoba(imie, nazwisko);
            else System.out.println("Room is not empty");
        }
        else System.out.println("Wrong room number");
    }

    /**
     * Metoda wymeldowuje osob� z wybranego pokoju
     * @param room
     *          Numer wybranego pokoju
     */
    public void makeEmpty(int room)
    {
        if(tablica[room]!=null) tablica[room]=null;
        else System.out.println("Room is already empty");
    }

    /**
     * Metoda zamieniaj�ca osoby z dw�ch wybranych pokoi
     * @param room1
     *          pierwszy wybrany pok�j
     * @param room2
     *          drugi wybrany pok�j
     */
    public void roomSwitch(int room1, int room2)
    {
        Osoba tmp=tablica[room1];
        tablica[room1]=tablica[room2];
        tablica[room2]=tmp;
    }

    /**
     * @return ilosc
     *          Ilo�� wolnych pokoi
     */
    public int amountOfEmpty()
    {
        int ilosc=0;
        for(int i=1; i<tablica.length;i++)
        {
            if(tablica[i]==null) ilosc++;
        }
        return ilosc;
    }

    /**
     * @return tab
     *          Tablica pustych pokoi
     */
    public int[] findEmpty()
    {
        int[] tab=new int[amountOfEmpty()];
        int j=0;

        for(int i=1; i<tablica.length;i++)
        {
            if(tablica[i]==null)
            {
                tab[j]=i;
                j++;
            }
        }
        return tab;
    }

    /**
     * Metoda przypisuj�ca osoby do 50 losowo wybranych pustych pokoi, je�li takowa ich ilo�� istnieje
     */
    public void getRoomByRandom()
    {
        int[] shuffledTab=new int[amountOfEmpty()];
        shuffledTab=shuffleArray(findEmpty());
        if(amountOfEmpty()>=50)
        {
            for(int i=0;i<=50;i++)
            {
                tablica[shuffledTab[i]]=new Osoba();
            }
        }
        else System.out.println("Cannot find 50 empty rooms");

    }


    /**
     * Metoda tasuj�ca tablic�
     * @param array
     *          Podana tablica do tasowania
     * @return array
     *      Potasowana tablica
     */
    public int[] shuffleArray(int[] array){
        Random rand = new Random();

        for (int i=0; i<array.length; i++) {
            int randPosition = rand.nextInt(array.length);
            int temp = array[i];
            array[i] = array[randPosition];
            array[randPosition] = temp;
        }

        return array;


    }

    /**
     * Metoda wypisuje wszystkie pokoje wraz z informacjami o go�ciach
     */
    public void roomInfo()
    {
        for(int i=1;i<tablica.length;i++)
        {
            if(tablica[i]!=null) System.out.println("Room "+i+": "+tablica[i].imie+" "+tablica[i].nazwisko);
            else System.out.println("Room "+i+" is empty");
        }
    }

    /**
     * W ramach test�w
     */
    public static void main(String[] args)
        {
            Hotel hotel=new Hotel();
            System.out.println(Arrays.toString(hotel.findEmpty()));
        }

}







