/**
 * Klasa reprezentuj�ca osob�
 * @author Piotr Palus
 * 18.11.2015
 */
public class Osoba
{
    String imie;
    String nazwisko;

    /**
     * Konstruktor
     * @param imie
     *          Imi� osoby
     * @param nazwisko
     *          Nazwisko osoby
     */
    public Osoba(String imie, String nazwisko)
    {
        this.imie=imie;
        this.nazwisko=nazwisko;

    }

    /**
     * Konstruktor
     */
    public Osoba()
    {

    }
}
