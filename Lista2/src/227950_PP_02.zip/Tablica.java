import java.util.*;

/**
 * Klasa przechowuj�ca do 1000 liczb ca�kowitych
 * @author Piotr Palus
 * 18.11.2015
 */

public class Tablica
{
    public int[] tablica;
    public int amount;

    /**
     * Konstruktor tablicy
     * @param amount
     *          ile element�w ma by� w tablicy
     */
    public Tablica(int amount)
    {
        if(amount>0&&amount<=1000)
        {
            tablica=new int[amount];
            this.amount=amount;

        }
        else System.out.println("Wrong amount");
    }

    /**
     * Metoda wype�niaj�ca tablic� losowymi liczbami z podanego zakresu
     * @param begin
     *          dolna granica zakresu
     * @param end
     *          g�rna granica zakresu
     */
    public void random(int begin, int end)
    {
        Random rand=new Random();
        for(int i=0; i<amount; i++)
        {
            tablica[i]=rand.nextInt(end-begin+1)+begin;
        }

    }

    /**
     * @return sum
     *          suma wszystkich elemnt�w tablicy
     */

    public int sum()
    {
        int sum=0;
        for(int i=0; i<amount; i++)
        {
            sum+=tablica[i];

        }
        return sum;
    }

    /**
     * @return max
     *          maksymalna warto�� w tablicy
     */
    public int findMax()
    {
        int max=tablica[0];
        for(int i=0; i<amount; i++)
        {
            if(tablica[i]>max) max=tablica[i];
        }
        return max;
    }

    /**
     * Metoda usuwaj�ca zadan� warto�� w tablicy
     * @param x
     *          warto��, kt�r� chcemy usun��
     */
    public void remove(int x)
    {
        int ilosc=0;

        for(int i=0; i<amount; i++)
        {
            if(tablica[i]==x) ilosc++;
        }

        int[] tablica2=new int[amount-ilosc];

        int j=0;
        for(int i=0; i<amount; i++)
        {
            if(tablica[i]!=x)
            {
                tablica2[j]=tablica[i];
                j++;
            }


        }

        tablica=tablica2;

    }

    /**
     * Metoda wy�wietlaj�ca wszystkie elementy tablicy
     */
    public void arrayShow()
    {
        System.out.println(Arrays.toString(tablica));
    }




}
