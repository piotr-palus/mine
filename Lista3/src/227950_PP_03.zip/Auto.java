/**
 * Klasa reprezentująca auto
 * @author Piotr Palus
 * 18.11.2015
 */
public class Auto
    extends Pojazd
{

    /**
     * Metoda obliczająca koszt utrzymania auta
     * @param km
     *          Liczba przejechanych kilometrów
     * @param hours
     *          Liczba przejechanych godzin
     * @return upkeep
     *          Koszt utrzymania auta
     */
    @Override
    public double upkeep(double km, double hours)
    {
        double upkeep=upkeepKm*km;

        return upkeep;
    }

}

