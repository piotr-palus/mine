/**
 * Klasa reprezentująca pojazd
 * @author Piotr Palus
 * 18.11.2015
 */
public abstract class Pojazd
{
    double maxV;
    double heightMax;
    double upkeepKm;
    double upkeepH;
    int id;

    /**
     * Metoda abstrakcyjna ukonkretniona w klasach potomnych
     * @param km
     *          Liczba przejechanych/przelacianych kilometrów
     * @param hours
     *          Liczba przejechanych/przelecianych godzin
     */
    public abstract double upkeep(double km, double hours);

}
