/**
 * Klasa reprezentująca firmę
 * @author Piotr Palus
 * 18.11.2015
 */

import java.util.*;

public class Firma
{
    List<Pojazd> lista= new ArrayList<Pojazd>();

    /**
     * Metoda zwracają referencję do pojazdu o danym id
     * @param id
     *          id wybranego pojazdu
     * @return lista.get(i)
     *          referencja do danego pojazdu o wybranym id, jeśli istnieje
     */
    public Pojazd vehicleRef(int id)
    {
        int i=0;

        while(lista.size()>i)
        {
            if(lista.get(i).id==id) break;
            else i++;
        }

        if(lista.size()==i) return null;
        else return lista.get(i);
    }

    /**
     * Metoda dodająca pojazd danego typu
     * @param type
     *          Typ dodawanego pojazdu
     */
    public void addVehicle(Pojazd type)
    {
        lista.add(type);
    }

    /**
     * Metoda usuwająca pojazd o danym id
     * @param id
     *          id wybranego pojazdu
     */
    public void removeVehiclebyId(int id)
    {
        int i=0;

        while(lista.size()>i)
        {
            if(lista.get(i).id==id)
            {
                lista.remove(i);
                break;
            }
            else i++;
        }

    }

    /**
     * Metoda dodająca odpowiednią liczbę pojazdów każdego rodzaju
     * @param auto
     *          Liczba dodawanych aut
     * @param train
     *          Liczba dodawanych pociągów
     * @param plane
     *          Liczba dodawanych samolotów
     */
    public void addMany(int auto, int train, int plane)
    {
        int i=0;

        while(i<auto)
        {
            lista.add(new Auto());
            i++;
        }
        i=0;
        while(i<train)
        {
            lista.add(new Kolej());
            i++;
        }
        i=0;
        while(i<plane)
        {
            lista.add(new Samolot());
            i++;
        }

    }

    /**
     * Metoda obliczają koszt utrzymania pojazdu
     * @param id
     *          id pojazdu
     * @param kmAmount
     *          Liczba przejechanych/przelecianych kilometrów pojazdu
     * @param hoursAmount
     *          Liczba przejechanych/przelecianych godzin pojazdu
     */
    public double upkeep(int id, double kmAmount, double hoursAmount)
    {
        int i=0;

        while(i<lista.size())
        {
            if(lista.get(i).id==id) break;
            else i++;
        }

        if(i==lista.size()) return 0;
        else return lista.get(i).upkeep(kmAmount,hoursAmount);



    }


    /**
     * Na potrzeby testów
     */
    public static void main(String[] args)
    {
        Firma firma=new Firma();
        firma.addMany(5,5,5);









    }

}

