/**
 * Klasa reprezentująca samolot
 * @author Piotr Palus
 * 18.11.2015
 */
public class Samolot
    extends Pojazd
{
    /**
     * Metoda obliczająca koszt utrzymania samolotu
     * @param km
     *          Liczba przelecianych kilometrów
     * @param hours
     *          Liczba przelecianych godzin
     * @return upkeep
     *          Koszt utrzymania samolotu
     */
    @Override
    public double upkeep(double km, double hours)
    {
        double upkeep=upkeepH*hours+(maxV/100)*hours;

        return upkeep;
    }
}
