/**
 * Klasa reprezentująca kolej
 * @author Piotr Palus
 * 18.11.2015
 */
public class Kolej
    extends Pojazd
{
    int carriageAmount;

    /**
     * Metoda obliczająca koszt utrzymania pociągu
     * @param km
     *          Liczba przejechanych kilometrów
     * @param hours
     *          Liczba przejechanych godzin
     * @return upkeep
     *          Koszt utrzymania pociągu
     */
    @Override
    public double upkeep(double km, double hours)
    {
        double upkeep=upkeepKm*km+upkeepH*hours;

        return upkeep;
    }
}
