import java.util.*;
/**
 * Klasa przedstawiająca pracownika
 * @author Piotr Palus
 * 02.12.2015
 */
public class Worker
{
    List<Worker> list = new ArrayList<Worker>();

    /**
     * Metoda dodająca pracownika do listy
     * @param w
     *          Dodawany pracownik
     */
    public void add_worker(Worker w)
    {
        list.add(w);
    }

    /**
     * Metoda zwracająca losowego pracownika z listy
     * @return list.get(los)
     *          Losowy pracownik z listy
     */
    public Worker choose_random_worker()
    {
        int los=0;
        Random rand = new Random();
        los=rand.nextInt(list.size());

        return list.get(los);

    }

    /**
     * Metoda wybierająca co n-tego pracownika z listy
     * @param n
     *          Co który pracownik ma być wybrany
     * @return tab
     *          Tablica wybranych co n-tych pracowników
     */
    public Worker[] choose_every_nth_worker(int n)
    {
        Worker[] tab = new Worker[list.size()/n-1];
        int count_tab=0;
        for(int i=0;i<tab.length;i+=3)
        {
            tab[count_tab]=list.get(i);
            count_tab++;
        }

        return tab;

    }



}
