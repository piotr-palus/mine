import java.util.*;
/**
 * Klasa przedstawiająca zadanie
 * @author Piotr Palus
 * 02.12.2015
 */
public class Task
{
    Map<Worker,Task> tasks = new HashMap<Worker, Task>();

    /**
     * Metoda przypisująca pracownika do zadania, jeśli go jeszcze nie ma
     * @param w
     *          Dodawany pracownik
     * @param t
     *          Dodowane zadanie
     */
    public void assign_worker_to_task(Worker w, Task t)
    {
        if(!tasks.containsKey(w)) tasks.put(w,t);
        else System.out.println("This task exists already");
    }

    /**
     * Metoda zwalniająca pracownika od zadania
     * @param w
     *          Dany pracownik
     */
    public void unassign_worker(Worker w)
    {
        if(tasks.containsKey(w)) tasks.remove(w);
        else System.out.println("This worker do not exist!");
    }

    /**
     * Metoda zwracająca zadanie pracownika, jeśli istnieje
     * @param w
     *          Dany pracownik
     * @return tasks.get(w)/null
     *          Zadanie pracownika/Jeśli pracownik nie istnieje w spisie
     */
    public Task get_worker_task(Worker w)
    {
        if(tasks.containsKey(w)) return tasks.get(w);
        else return null;
    }

    /**
     * Metoda zwracająca pierwszego pracownika przypisanego do danego zadania
     * @param t
     *          Dane zadanie
     * @return i.getKey()/null
     *          Pracownik z danym zadaniem/Jeśli dane zadanie nie jest przypisane do żadnego pracownika
     */
    public Worker get_assigned_worker(Task t)
    {
        if(tasks.containsValue(t))
        {
            for(Map.Entry<Worker,Task> i : tasks.entrySet())
            {
                if(i.getValue()==t) return i.getKey();
            }

        }

        return null;
    }

}
