import java.util.*;

/**
 * Klasa przedstawiająca zbiór unikalnych e-maili
 * @author Piotr Palus
 * 02.12.2015
 */
public class Email
{
    Set<String> set=new HashSet<String>();

    /**
     * Metoda dodająca do zbioru dany e-mail
     * @param email
     *          Wybrany e-mail do dodania
     */
    public void add_new_email(String email)
    {
        set.add(email);
    }

    /**
     * Metoda usuwająca ze zbioru dany e-mail, jeśli istnieje
     * @param email
     *          Wybrany email do usunięcia
     */
    public void remove_email(String email)
    {
        if(set.contains(email)) set.remove(email);
    }

    /**
     * Metoda sprawdzająca czy dany e-mail istnieje w zbiorze
     * @param email
     *          Wybrany e-mail
     * @return true/false
     *          Jeśli e-mail istnieje w zbiorze/Jeśli e-mail nie istnieje w zbiorze
     *
     */
    public boolean check_if_email_exists(String email)
    {
        if(set.contains(email)) return true;
        else return false;
    }



}
